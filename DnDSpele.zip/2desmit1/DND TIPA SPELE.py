import tkinter as tk
import random
from PIL import Image, ImageTk

# sākuma vērtības
p1 = p2 = 20
beigas = False

def SagatavoAttelu(p):
    att = [
        "atteli/dice1.png",
        "atteli/dice2.png",
        "atteli/dice3.png",
        "atteli/dice4.png",
        "atteli/dice5.png",
        "atteli/dice6.png"
    ]
    attels = Image.open(att[p-1])
    w, h = attels.size
    platums = int(w * 0.5)
    augstums = int(h * 0.5)
    attels = attels.resize((platums, augstums))
    foto = ImageTk.PhotoImage(attels)
    return foto

def MetKaulinu1(event):
    mkaulins1.unbind("<Button>")
    metieni = 0
    rezultats_p = 0
    def Animacija():
        nonlocal metieni, rezultats_p
        global p2, beigas
        metieni += 1
        rezultats_p = random.randint(1, 6)
        if metieni <= 10:
            jkaulins = SagatavoAttelu(rezultats_p)
            mkaulins1.config(image=jkaulins)
            mkaulins1.image = jkaulins
            mkaulins1.after(100, Animacija)
        if metieni == 10:
            if p2 <= 6:
                if rezultats_p == p2:
                    p2 = 0
                # ja nav precīzi, HP nemainās
            else:
                p2 -= rezultats_p
            punkti2.config(text=f"HP: {p2}")
            if p2 <= 0:
                beigas = True
            ramis.after(500, Paslept1Paradit2)
    Animacija()

def MetKaulinu2(event):
    mkaulins2.unbind("<Button>")
    metieni = 0
    rezultats_p = 0
    def Animacija():
        nonlocal metieni, rezultats_p
        global p1, beigas
        metieni += 1
        rezultats_p = random.randint(1, 6)
        if metieni <= 10:
            jkaulins = SagatavoAttelu(rezultats_p)
            mkaulins2.config(image=jkaulins)
            mkaulins2.image = jkaulins
            mkaulins2.after(100, Animacija)
        if metieni == 10:
            if p1 <= 6:
                if rezultats_p == p1:
                    p1 = 0
                # ja nav precīzi, HP nemainās
            else:
                p1 -= rezultats_p
            punkti1.config(text=f"HP: {p1}")
            if p1 <= 0:
                beigas = True
            ramis.after(500, Paslept2Paradit1)  
    Animacija()

def Paslept1Paradit2():
    global beigas
    mkaulins1.grid_forget()
    if beigas == False:
        mkaulins2.grid(row=2, column=1, pady=10)
        mkaulins2.bind("<Button>", MetKaulinu2)  
    else:
        mkaulins2.grid_forget()
        Rezultats()

def Paslept2Paradit1():
    global beigas
    mkaulins2.grid_forget()
    if beigas == False:
        mkaulins1.grid(row=2, column=0, pady=10)
        mkaulins1.bind("<Button>", MetKaulinu1)  
    else:
        mkaulins1.grid_forget()
        Rezultats()

def Rezultats():
    if p1 <= 0:
        rezultats.config(text="Uzvar 2. spēlētājs!")
    elif p2 <= 0:
        rezultats.config(text="Uzvar 1. spēlētājs!")

def Reset():
    global p1, p2, beigas
    p1 = 20
    p2 = 20
    beigas = False
    punkti1.config(text="HP: 20")
    punkti2.config(text="HP: 20")
    rezultats.config(text="...")
    mkaulins2.grid_forget()
    mkaulins1.grid(row=2, column=0, pady=10)
    mkaulins1.bind("<Button>", MetKaulinu1)  
    mkaulins2.unbind("<Button>")             

# izveido Tkinter logu
logs = tk.Tk()
logs.title("-= Iznīcini pretinieka HP =-")
logs.geometry("600x400")

virsraksts = tk.Label(text="-= Iznīcini pretinieka HP =-", fg="#B40000", font=("Verdana", 24, "bold"))
virsraksts.pack(pady=20)

ramis = tk.Frame(logs)
ramis.pack(fill=tk.X, pady=5)
ramis.grid_columnconfigure(0, weight=1)
ramis.grid_columnconfigure(1, weight=1)

reset_poga = tk.Button(logs, text="RESET", command=Reset, width=10, height=2, fg="#B40000", font=("Verdana", 12))
reset_poga.pack(pady=5)

punkti1 = tk.Label(ramis, text=f"HP: {p1}", font=("Verdana", 14, "bold"))
punkti2 = tk.Label(ramis, text=f"HP: {p2}", font=("Verdana", 14, "bold"))
punkti1.grid(row=0, column=0)
punkti2.grid(row=0, column=1)
speletajs1 = tk.Label(ramis, text="1. Spēlētājs", font=("Verdana", 12))
speletajs2 = tk.Label(ramis, text="2. Spēlētājs", font=("Verdana", 12))
speletajs1.grid(row=1, column=0)
speletajs2.grid(row=1, column=1)

foto1 = SagatavoAttelu(random.randint(1, 6))
mkaulins1 = tk.Label(ramis, image=foto1)
mkaulins1.grid(row=1, column=0, pady=10)
foto2 = SagatavoAttelu(random.randint(1, 6))
mkaulins2 = tk.Label(ramis, image=foto2)
mkaulins2.grid_forget()
mkaulins1.bind("<Button>", MetKaulinu1)
mkaulins2.bind("<Button>", MetKaulinu2)

rezultats = tk.Label(text="...", fg="#B40000", font=("Verdana", 16, "bold"))
rezultats.pack(side=tk.BOTTOM, pady=100)

logs.mainloop()